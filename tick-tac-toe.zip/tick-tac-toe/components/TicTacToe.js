import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';

// Initialize an empty board with 9 slots
const initialBoard = Array(9).fill(null);

// Function to check for a winner or a draw
const checkWinner = (board) => {
  const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6] // Diagonals
  ];
  for (let [a, b, c] of lines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return board[a]; // Return the winning player ('X' or 'O')
    }
  }
  return board.includes(null) ? null : 'Draw'; // If no empty slots, it's a draw
};

export default function TicTacToe() {
  const [board, setBoard] = useState(initialBoard);
  const [player, setPlayer] = useState('X'); // Start with player 'X'
  const [history, setHistory] = useState([]); // Store game history

  // Function to handle player moves
  const handlePress = (index) => {
    if (board[index] || checkWinner(board)) return; // Ignore if cell is occupied or game over
    const newBoard = board.slice();
    newBoard[index] = player;
    setBoard(newBoard);
    const winner = checkWinner(newBoard);
    if (winner) {
      setHistory([...history, { board: newBoard, winner }]); // Store completed game in history
    }
    setPlayer(player === 'X' ? 'O' : 'X'); // Switch turn to the other player
  };

  // Function to reset the game
  const resetGame = () => {
    setBoard(initialBoard);
    setPlayer('X'); // Reset to player 'X'
  };

  // Render a snapshot of the board
  const renderBoardSnapshot = (board) => {
    return (
      <View style={styles.board}>
        {board.map((cell, index) => (
          <View key={index} style={styles.cell}>
            <Text style={styles.cellText}>{cell}</Text>
          </View>
        ))}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tic Tac Toe</Text>
      
      {/* Game Board */}
      <View style={styles.board}>
        {board.map((cell, index) => (
          <TouchableOpacity key={index} style={styles.cell} onPress={() => handlePress(index)}>
            <Text style={styles.cellText}>{cell}</Text>
          </TouchableOpacity>
        ))}
      </View>
      
      {/* Display current player */}
      <Text style={styles.status}>Next Player: {player}</Text>
      
      {/* Restart Button */}
      <TouchableOpacity style={styles.button} onPress={resetGame}>
        <Text style={styles.buttonText}>Restart</Text>
      </TouchableOpacity>
      
      {/* Game History */}
      <Text style={styles.historyTitle}>Game History</Text>
      <FlatList
        data={history}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.historyItem}>
            <Text>Game {index + 1}: Winner - {item.winner}</Text>
            {renderBoardSnapshot(item.board)} {/* Render the board snapshot */}
          </View>
        )}
      />
    </View>
  );
}

// Styling for the components
const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  board: { width: 300, height: 300, flexDirection: 'row', flexWrap: 'wrap' },
  cell: { width: 100, height: 100, justifyContent: 'center', alignItems: 'center', borderWidth: 1 },
  cellText: { fontSize: 36, fontWeight: 'bold' },
  status: { fontSize: 20, margin: 10 },
  button: { backgroundColor: 'blue', padding: 10, borderRadius: 5, marginTop: 10 },
  buttonText: { color: 'white', fontSize: 16 },
  historyTitle: { fontSize: 18, fontWeight: 'bold', marginTop: 20 },
  historyItem: { padding: 10, borderBottomWidth: 1, width: '100%', alignItems: 'center' }
});
